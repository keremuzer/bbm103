for i in range(8):
    print((i + 1) * '*')
